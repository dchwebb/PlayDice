// carry out the screen refresh building the various UI elements
void updateDisplay() {
	if (DEBUGFRAME) {
		Serial.print("Frame start: "); Serial.print(millis());
	}

	display.clearDisplay();

	//	Write the sequence number for sequence A
	display.setCursor(1, 10);
	display.setTextSize(2);
	display.println(sequenceA);
	display.setTextSize(1);

	//	Draw arrow beneath sequence number if selected for editing
	if (editStep == -1) {
		display.drawLine(4, 34, 6, 32, WHITE);
		display.drawLine(6, 32, 8, 34, WHITE);
	}

	// Draw the sequence steps for pattern A (sample and hold)
	for (int i = 0; i < 8; i++) {
		int voltHPos = 17 + (i * 14);
		int voltVPos = 27 - (seq.Steps[i].volts * 5);

		// Draw voltage line showing randomisation by using a dotted line with 3 or 4 dots if randomisation is greater or less than 5
		if (seq.Steps[i].rand_amt > 0) {
			for (int j = 0; j < 12; j++) {
				if (j % (seq.Steps[i].rand_amt > 5 ? 4 : 3) == 0) {
					display.drawPixel(voltHPos + (seq.Steps[i].rand_amt > 5 ? 2 : 1) + j, voltVPos, WHITE);
					display.drawPixel(voltHPos + (seq.Steps[i].rand_amt > 5 ? 2 : 1) + j, voltVPos + 1, WHITE);
				}
			}
		}
		else {
			display.drawFastHLine(voltHPos, voltVPos, 13, WHITE);
			display.drawFastHLine(voltHPos, voltVPos + 1, 13, WHITE);
		}

		// draw amount of voltage selected after randomisation applied
		if (seqStep == i) {
			// Draw voltage line
			display.fillRect(voltHPos, round(26 - (randAmt * 5)), 13, 4, WHITE);
		}

		//	Draw arrow beneath step selected for editing
		if (editStep == i) {
			display.drawLine(voltHPos + 4, 34, voltHPos + 6, 32, WHITE);
			display.drawLine(voltHPos + 6, 32, voltHPos + 8, 34, WHITE);
		}

		display.setCursor(91, 50);
		display.print("b: "); display.println(bpm);
	}

	//	if deep editing voltage or randomisation show values in bottom area of screen
	if (editMode == STEPR || editMode == STEPV) {
		display.setCursor(10, 43);
		display.println("Volts");
		display.setCursor(10, 53);
		display.println(seq.Steps[editStep].volts);
		if (editMode == STEPV) {
			display.drawRect(5, 40, 41, 24, INVERSE);
		}

		display.setCursor(50, 43);
		display.println("Random");
		display.setCursor(50, 53);
		display.println(seq.Steps[editStep].rand_amt);
		if (editMode == STEPR) {
			display.drawRect(45, 40, 44, 24, INVERSE);
		}
	}

	if (editMode == SEQS || editMode == SEQMODE) {
		display.setCursor(10, 43);
		display.println("Sequences");
		display.setCursor(10, 53);
		display.println(numSeqA);
		if (editMode == SEQS) {
			display.drawRect(5, 40, 41, 24, INVERSE);
		}

		display.setCursor(50, 43);
		display.println("Mode");
		display.setCursor(50, 53);
		display.println(modeSeqA);
		if (editMode == SEQMODE) {
			display.drawRect(45, 40, 44, 24, INVERSE);
		}
	}

	display.display();
	displayRefresh = REFRESHOFF;

	if (DEBUGFRAME) {
		Serial.print("  Frame end: "); Serial.println(millis());
	}
}