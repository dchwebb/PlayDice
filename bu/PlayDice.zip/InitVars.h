#pragma once
#define LED 13
#define TEMPOPIN 9
#define DACPIN 40
#define BTNUPPIN 12
#define BTNDNPIN 11
#define BTNENCPIN 10
#define ENCCLKPIN 5
#define ENCDATAPIN 6
